<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DealCategoryController;
use App\Http\Controllers\Admin\DealController;
use App\Http\Controllers\Admin\PurposeController;
use App\Http\Controllers\Admin\VideoController;
use App\Http\Controllers\Admin\ScemeController;
use App\Http\Controllers\Admin\LanguageController;
use App\Http\Controllers\Admin\CustomerController;
use App\Http\Controllers\Admin\PageController;
use App\Http\Controllers\Admin\SliderController;
use App\Http\Controllers\Admin\DealHistoryController;
use App\Http\Controllers\Api\PDFController;

Route::get('/', function () {
    return view('admin.dashboard.index');
})->name('dashboard.index');

Route::get('admin/profile', function () {
    return view('admin.profile.index');
})->name('profile.index');


// Deal Categories Route
Route::resource('deal_categories', DealCategoryController::class);
Route::patch('deal_categories/status_changes/{id}', [DealCategoryController::class, 'status_changes'])->name('status_changes'); 


// Purpose Route
Route::resource('purposes', PurposeController::class);
Route::patch('purposes/status_changes/{id}', [PurposeController::class, 'status_changes'])->name('status_changes_purpose');

// Scemes Routes
Route::resource('scemes', ScemeController::class);
Route::patch('scemes/status_changes/{id}', [ScemeController::class, 'status_changes'])->name('status_changes_scemes');


// Languages Route
Route::resource('languages', LanguageController::class);

// Customers Route
Route::resource('customers', CustomerController::class);
Route::patch('customer/status_changes/{id}', [CustomerController::class, 'status_changes'])->name('customers.status_changes');

// Video Routes 
Route::resource('videos', VideoController::class);
Route::get('videos', [VideoController::class, 'index'])->name('videos.index');
Route::put('/videos/{video}', [VideoController::class, 'update'])->name('videos.update');
Route::get('videos/{id}', [VideoController::class, 'show'])->name('videos.show');
Route::delete('videos/{id}', [VideoController::class, 'destroy'])->name('videos.destroy');

// Deal Controller 
Route::resource('deals', DealController::class);
Route::get('/mediator/{sakshiId}', [DealController::class, 'getMediatorBySakshi']);
Route::get('/deals/{id}/history', [DealController::class, 'showDealHistory'])->name('deals.history');


// Page Routes 
Route::resource('pages', PageController::class);
Route::get('get-pages', [PageController::class, 'getPages'])->name('pages.getPages');
Route::patch('pages/{id}/status', [PageController::class, 'statusChange'])->name('pages.status_change');

// Slider Routes
Route::resource('sliders', SliderController::class);
Route::patch('/sliders/{id}/toggle-status', [SliderController::class, 'toggleStatus'])->name('sliders.toggleStatus');

// aggriments 
Route::get('generate-pdf', [PDFController::class, 'generatePDFx']);
// Deal History Route 
// Route::get('/admin/deals', [DealHistoryController::class, 'index'])->name('admin.deals-list');
// Route::get('/admin/deal-history/{id}', [DealHistoryController::class, 'showDealHistory'])->name('admin.deal-history');