<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\api\DealCategoryController;
use App\Http\Controllers\api\LanguageController;
use App\Http\Controllers\api\PurposeController;
use App\Http\Controllers\api\CustomerController;
use App\Models\Sceme;
use App\Http\Controllers\api\DealController;
use App\Http\Controllers\api\PageController;
use App\Http\Controllers\Api\OtpController;
use App\Http\Controllers\Api\AadharInfoController;
use App\Http\Controllers\Api\SliderController;
use App\Http\Controllers\api\PDFController;


Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

// Deal Category Routes
Route::get('/deal_categories', [DealCategoryController::class, 'index'])->name('api.dealCategories.index');
Route::post('/deal_categories/create', [DealCategoryController::class, 'store'])->name('api.dealCategories.store');
Route::get('/deal_categories/show/{deal_category}', [DealCategoryController::class, 'show'])->name('api.dealCategories.show');
Route::post('/deal_categories/update/{deal_category}', [DealCategoryController::class, 'update'])->name('api.dealCategories.update');
Route::delete('/deal_categories/delete/{deal_category}', [DealCategoryController::class, 'destroy'])->name('api.dealCategories.destroy');
Route::put('/deal_categories/status_changes/{id}', [DealCategoryController::class, 'status_changes'])->name('api.dealCategories.statusChanges');

// Language Routes
Route::get('/languages', [LanguageController::class, 'index'])->name('api.languages.index');
Route::post('/languages/create', [LanguageController::class, 'store'])->name('api.languages.store');
Route::get('/languages/show/{language}', [LanguageController::class, 'show'])->name('api.languages.show');
Route::post('/languages/update/{language}', [LanguageController::class, 'update'])->name('api.languages.update');
Route::delete('/languages/delete/{language}', [LanguageController::class, 'destroy'])->name('api.languages.destroy');

// Purposes Routes
Route::get('/purposes', [PurposeController::class, 'index'])->name('api.purposes.index');
Route::post('/purposes/create', [PurposeController::class, 'store'])->name('api.purposes.store');
Route::get('/purposes/show/{purpose}', [PurposeController::class, 'show'])->name('api.purposes.show');
Route::post('/purposes/update/{purpose}', [PurposeController::class, 'update'])->name('api.purposes.update');
Route::delete('/purposes/delete/{purpose}', [PurposeController::class, 'destroy'])->name('api.purposes.destroy');

// Customers Routes
Route::get('/customers', [CustomerController::class, 'index'])->name('api.customers.index');
Route::post('/customers/create', [CustomerController::class, 'store'])->name('api.customers.store');
Route::get('/customers/show/{customer}', [CustomerController::class, 'show'])->name('api.customers.show');
Route::post('/customers/update/{customer}', [CustomerController::class, 'update'])->name('api.customers.update');
Route::delete('/customers/delete/{customer}', [CustomerController::class, 'destroy'])->name('api.customers.destroy');
Route::get('get_customer_by_mobile', [CustomerController::class, 'getCustomerByMobile']);
Route::post('upload_image', [CustomerController::class, 'upload_image']);

Route::get('scemelist', function () {
    return Sceme::select('id', 'emi_pay_method')->get();
});

// Pages Route
Route::get('/pages', [PageController::class, 'index'])->name('api.pages.index');
Route::post('/pages/create', [PageController::class, 'store'])->name('api.pages.store');
Route::get('/pages/show/{page}', [PageController::class, 'show'])->name('api.pages.show');
Route::post('/pages/update/{page}', [PageController::class, 'update'])->name('api.pages.update');
Route::delete('/pages/delete/{page}', [PageController::class, 'destroy'])->name('api.pages.destroy');

// Deal Route
Route::get('/deal_history/{id}', [DealController::class, 'showDealHistory']);

// OTP Verify Route
Route::post('/customer_register', [OtpController::class, 'registerCustomer']);
Route::post('/verify_mobile', [OtpController::class, 'sendOtp'])->name('otp.send');
Route::post('/verify_mobile_otp', [OtpController::class, 'verifyOtp'])->name('otp.verify');

// Aadhar Info Route
Route::post('/aadhar_info', [AadharInfoController::class, 'store']);
Route::get('/aadhar_info/{id}', [AadharInfoController::class, 'show']);
Route::post('/aadhar_info/{id}', [AadharInfoController::class, 'update']);
Route::delete('/aadhar_info/{id}', [AadharInfoController::class, 'destroy']);

// Slider Routes
Route::get('sliders', [SliderController::class, 'index'])->name('sliders.index'); // Get all sliders
Route::post('sliders/create', [SliderController::class, 'store'])->name('sliders.store'); // Create a new slider
Route::get('sliders/{id}', [SliderController::class, 'show'])->name('sliders.show'); // Get a specific slider by ID
Route::post('sliders/update/{id}', [SliderController::class, 'update'])->name('sliders.update'); // Update a specific slider by ID
Route::delete('sliders/{id}', [SliderController::class, 'destroy'])->name('sliders.destroy'); // Delete a specific slider by ID

Route::get('generate-pdf', [PDFController::class, 'generatePDF']);
// Route::get('/print-affidavit', [PDFController::class, 'printAffidavit']);
Route::get('/rent_agreement', [PDFController::class, 'printAffidavit']);
Route::post('attribute/list',[AttributeController::class, 'list' ])->name('attribute.list');