<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Invoice {{ $invoice->invoice_number }}</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 14px; color: #333; }
        .invoice-header { margin-bottom: 30px; }
        .invoice-header h1 { margin: 0; font-size: 24px; }
        .invoice-info, .customer-info { margin-bottom: 20px; }
        .invoice-info td, .customer-info td { padding: 5px; }
        .table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .table th, .table td { border: 1px solid #ddd; padding: 8px; }
        .text-right { text-align: right; }
        .badge { padding: 6px 10px; color: #fff; border-radius: 4px; }
        .badge-success { background-color: #198754; }
        .badge-warning { background-color: #ffc107; color: #000; }
    </style>
</head>
<body>
    @php
        $invoiceDate = 'N/A';
        if ($invoice->invoice_date instanceof \DateTimeInterface) {
            $invoiceDate = $invoice->invoice_date->format('Y-m-d');
        } elseif (!empty($invoice->invoice_date)) {
            try {
                $invoiceDate = \Illuminate\Support\Carbon::parse($invoice->invoice_date)->format('Y-m-d');
            } catch (\Exception $e) {
                $invoiceDate = 'N/A';
            }
        }
    @endphp
    <div class="invoice-header">
        <h1>Invoice</h1>
        <p>Invoice Number: {{ $invoice->invoice_number }}</p>
        <p>Date: {{ $invoiceDate }}</p>
    </div>

    <table class="table customer-info">
        <tr>
            <th>Customer</th>
            <td>{{ $invoice->customer?->name ?? 'N/A' }}</td>
        </tr>
        <tr>
            <th>Plan</th>
            <td>{{ $invoice->subscriptionPlan?->name ?? 'N/A' }}</td>
        </tr>
        <tr>
            <th>Payment Status</th>
            <td><span class="badge {{ strtolower($invoice->payment_status) == 'paid' ? 'badge-success' : 'badge-warning' }}">{{ ucfirst($invoice->payment_status) }}</span></td>
        </tr>
        <tr>
            <th>Payment Method</th>
            <td>{{ ucfirst($invoice->payment_method ?? 'N/A') }}</td>
        </tr>
    </table>

    <table class="table">
        <thead>
            <tr>
                <th>Description</th>
                <th class="text-right">Amount</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>{{ $invoice->subscriptionPlan?->name ?? 'Subscription Plan' }}</td>
                <td class="text-right">₹ {{ number_format($invoice->amount, 2) }}</td>
            </tr>
            <tr>
                <th>Total</th>
                <th class="text-right">₹ {{ number_format($invoice->amount, 2) }}</th>
            </tr>
        </tbody>
    </table>
</body>
</html>
