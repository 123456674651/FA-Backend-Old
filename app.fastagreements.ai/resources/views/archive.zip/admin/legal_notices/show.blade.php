@extends('admin.layout.admin')

@section('content')
<main id="main" class="main">
    <div class="row">
        <div class="pagetitle col-lg-6 pt-2">
            <h1>Legal Notice Details</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('legal-notices.index') }}">Legal Notices</a></li>
                    <li class="breadcrumb-item active">View Details</li>
                </ol>
            </nav>
        </div>
        <div class="pagetitle col-lg-6 text-end pt-2">
            <a href="{{ route('legal-notices.index') }}" class="btn btn-secondary me-1">
                <i class="bi bi-arrow-left-square"></i> Back
            </a>
            <a href="{{ route('legal-notices.edit', $notice->id) }}" class="btn btn-primary">
                <i class="bi bi-pencil-square"></i> Edit
            </a>
        </div>
    </div>

    <section class="section">
        <div class="row">
            <!-- Left Column: Details -->
            <div class="col-lg-8">
                <!-- Opponent Company Details -->
                <div class="card mb-4">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <h4 class="card-title p-0 m-0">Opponent Details</h4>
                            @php
                                $badgeClasses = [
                                    'Pending' => 'bg-warning text-dark',
                                    'Approved' => 'bg-success text-white',
                                    'Rejected' => 'bg-danger text-white',
                                    'In Progress' => 'bg-info text-dark',
                                    'Closed' => 'bg-secondary text-white'
                                ];
                                $badgeClass = $badgeClasses[$notice->status] ?? 'bg-light';
                            @endphp
                            <span class="badge {{ $badgeClass }} fs-6">{{ $notice->status }}</span>
                        </div>
                        <hr class="mt-0">

                        <div class="row mb-3">
                            <div class="col-md-4 font-weight-bold"><strong>Company Name:</strong></div>
                            <div class="col-md-8 text-secondary">{{ $notice->company_name }}</div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4 font-weight-bold"><strong>Contact Person:</strong></div>
                            <div class="col-md-8 text-secondary">{{ $notice->company_person_name }}</div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4 font-weight-bold"><strong>Designation:</strong></div>
                            <div class="col-md-8 text-secondary">{{ $notice->company_person_designation }}</div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4 font-weight-bold"><strong>Company Address:</strong></div>
                            <div class="col-md-8 text-secondary" style="white-space: pre-line;">{{ $notice->company_address }}</div>
                        </div>
                    </div>
                </div>

                <!-- My Company Details -->
                <div class="card mb-4">
                    <div class="card-body p-4">
                        <h4 class="card-title p-0 mb-3">My Company Details</h4>
                        <hr class="mt-0">

                        <div class="row mb-3">
                            <div class="col-md-4 font-weight-bold"><strong>My Company Name:</strong></div>
                            <div class="col-md-8 text-secondary">{{ $notice->my_company_name }}</div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4 font-weight-bold"><strong>Business Nature:</strong></div>
                            <div class="col-md-8 text-secondary">{{ $notice->my_company_business_nature }}</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column: Financial & Meta Info -->
            <div class="col-lg-4">
                <!-- Financial Card -->
                <div class="card mb-4">
                    <div class="card-body p-4">
                        <h4 class="card-title p-0 mb-3">Financial Information</h4>
                        <hr class="mt-0">

                        <div class="mb-3">
                            <strong>Total Amount:</strong>
                            <h3 class="text-primary mt-1">₹{{ number_format($notice->total_amount, 2) }}</h3>
                        </div>

                        <div class="mb-3">
                            <strong>Amount Due:</strong>
                            <h3 class="text-danger mt-1">₹{{ number_format($notice->amount_due, 2) }}</h3>
                        </div>
                    </div>
                </div>

                <!-- Auditing / Audit Log Info Card -->
                <div class="card mb-4">
                    <div class="card-body p-4">
                        <h4 class="card-title p-0 mb-3">Auditing Details</h4>
                        <hr class="mt-0">

                        <div class="mb-2">
                            <strong>Created By User:</strong>
                            <p class="text-secondary">{{ $notice->user ? $notice->user->name : 'N/A' }} (ID: {{ $notice->user_id }})</p>
                        </div>

                        <div class="mb-2">
                            <strong>Created At:</strong>
                            <p class="text-secondary">{{ $notice->created_at ? $notice->created_at->format('Y-m-d H:i:s') : '-' }}</p>
                        </div>

                        <div class="mb-2">
                            <strong>Last Updated At:</strong>
                            <p class="text-secondary">{{ $notice->updated_at ? $notice->updated_at->format('Y-m-d H:i:s') : '-' }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
@endsection
