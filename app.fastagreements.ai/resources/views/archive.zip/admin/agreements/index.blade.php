@extends('admin.layout.admin')

@section('content')
<main id="main" class="main">

    <div class="row">
        <div class="pagetitle col-lg-6 pt-2">
            <h1>Agreement List</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}">Home</a></li>
                    <li class="breadcrumb-item active">Agreement List</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Agreement List</h5>
                        
                        <!-- Table with hoverable rows -->
                        <table class="table table-striped table-bordered" id="agreementTable">
                            <thead>
                                <tr>
                                    <th class="text-center align-middle" style="width: 5%;">Sr#</th>
                                    <th class="text-start align-start">Agreement Name</th>
                                    <th class="text-center align-middle">Party 1 Name</th>
                                    <th class="text-center align-middle">Party 2 Name</th>
                                    <th class="text-center align-middle">Created Date</th>
                                    <th class="text-center align-middle" style="width: 15%;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- DataTables will populate this table -->
                            </tbody>
                        </table>
                        <!-- End Table -->

                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- DataTables Scripts -->
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#agreementTable').DataTable({
                processing: true,
                serverSide: true,
                pageLength: 100,
                lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
                ajax: '{{ route('agreements.index') }}',
                columns: [
                    { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false, className: 'text-center align-middle' },
                    { data: 'agreement_name', name: 'agreement_name', className: 'text-center align-middle', orderable: false },
                    { data: 'party_1_name', name: 'party_1_name', className: 'text-center align-middle', orderable: false },
                    { data: 'party_2_name', name: 'party_2_name', className: 'text-center align-middle', orderable: false },
                    { data: 'created_at', name: 'created_at', className: 'text-center align-middle' },
                    { data: 'action', name: 'action', orderable: false, searchable: false, className: 'text-center align-middle' }
                ],
                autoWidth: false
            });
        });
    </script>
</main>
@stop
