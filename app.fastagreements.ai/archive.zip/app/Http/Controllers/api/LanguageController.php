<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use App\Models\Language;
use Exception;

class LanguageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            $languages = Language::where('is_active', 1)->orderBy('language_name')->get();

            $payload = $languages->map(function ($lang) {
                return [
                    'id' => $lang->id,
                    'name' => $lang->language_name,
                    'code' => $lang->language_code,
                ];
            })->values();

            return response()->json([
                'status' => true,
                'message' => 'Languages fetched successfully.',
                'data' => $payload
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while fetching languages.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

  
   
}
