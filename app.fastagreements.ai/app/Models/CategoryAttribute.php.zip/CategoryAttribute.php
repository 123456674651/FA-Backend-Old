<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class CategoryAttribute extends Model
{
    use HasFactory;

    protected $table = 'category_attributes';


    protected $appends = [
        'attribute_values_data'
    ];

    public function  getAttributeValuesDataAttribute() {
        
        if(!is_array($this->attribute_values) && $this->input_type == 2){

            return explode(',', $this->attribute_values);
        
        }else{
            return $this->attribute_values;
        }
        
    }
}
