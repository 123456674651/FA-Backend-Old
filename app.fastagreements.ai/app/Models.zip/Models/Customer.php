<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;

    protected $appends = [
        'person_image_url',
        'upi_image_url',
    ]; 

    protected $fillable = [
        'name',
        'mobile',
        'email',
        'address',
        'city_id',
        'state_id',
        'country_id',
        'per_address',
        'per_city_id',
        'per_state_id',
        'per_country_id',
        'person_image',
        'aadhaar_card',
        'is_aadhaar_verify',
        'aadhaar_card_all_column',
        'is_active',
        'is_payment_details_configured',
        'bank_name',
        'account_number',
        'ifsc',
        'account_type',
        'upi_id',
        'upi_image',
        'last_lat',
        'last_lon',
    ];

    // protected $casts = [
    //     'is_aadhaar_verify' => 'boolean',
    //     'aadhaar_card_all_column' => 'array',
    //     'is_active' => 'boolean',
    //     'is_payment_details_configured' => 'boolean',
    //     'last_lat' => 'decimal:10,7',
    //     'last_lon' => 'decimal:10,7',
    // ];

   // Accessor for person_image_url
   public function getPersonImageUrlAttribute()
   {
       return asset('admin/images/person_images_thumb/' . $this->person_image);
   }
   public function getUpiImageUrlAttribute()
   {
       return asset('admin/images/upi_images_thumb/' . $this->upi_image);
   }

    protected $casts = [
        'is_aadhaar_verify' => 'boolean',
        'aadhaar_card_all_column' => 'array',
        'is_active' => 'boolean',
        'is_payment_details_configured' => 'boolean',
        'last_lat' => 'decimal:7', // Only specify the scale
        'last_lon' => 'decimal:7', // Only specify the scale
    ];
    

}
