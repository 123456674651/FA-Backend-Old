<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DealCategory extends Model
{
    use HasFactory;

    public $appends = ['category_image_url'];

    protected $fillable = [
        'category_name',
        'category_image',
        'is_active',
        'deal_price',
        'is_on_interest',
        'description',
    ];

    public function getCategoryImageUrlAttribute()
    {
        return asset('admin/images/category_image_thumb/' . $this->category_image);
    }
}
