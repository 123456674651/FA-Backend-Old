<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Language;
use App\Models\DealCategory;
use App\Models\CategoryAttribute;
use Illuminate\Support\Facades\Validator;


class AttributeController extends Controller
{
    public function index(){

        
    }

    public function create(){
      
        $dealCategories = DealCategory::all(); 
        $languages = Language::all();


        return view('admin.attribute.create', compact( 'dealCategories', 'languages',));
    }

    public function store(Request $request){

        $validator = Validator::make($request->all(),[
            'category_id' => 'required',
            'attribute_name' => 'required',
            'attribute_value' => 'required',
            'input_type' => 'required',
            'default_value' => 'required',
            
        ]);

         // If validation fails, redirect back with errors
         if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $categorie_attribute = new CategoryAttribute;
        $categorie_attribute->category_id = $request->category_id;
        $categorie_attribute->attribute_name = $request->attribute_name;
        $categorie_attribute->attribute_values = $request->attribute_value;
        $categorie_attribute->input_type = $request->input_type;
        $categorie_attribute->default_value = $request->default_value;
        $categorie_attribute->sort_order = $request->category_id;
        $categorie_attribute->is_required = $request->is_required;
        $categorie_attribute->save();
       
       return redirect()->back()->with('success', 'Attribute added successfully!');

    }

    public function list(Request $request){

        $attributes = CategoryAttribute::where('is_active', 1)->where('category_id', $request->category_id)->get();
        foreach($attributes as $attribute){
            $array = $attribute->attribute_values;

            if(!is_array($attribute->attribute_values)  &&  $attribute->input_type == 2){
                $array = explode(',', $attribute->attribute_values);
            };

            $attribute->attribute_values = $array ;

        }

        return response()->json([
            'data' => $attributes
        ]);

    }
}
