<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Language;
use Yajra\DataTables\DataTables;

class LanguageController extends Controller
{
    public function index()
    {
        if (request()->ajax()) {
            return DataTables::of(Language::query())
                ->addIndexColumn()
                ->addColumn('action', function ($language) {
                    $editUrl = route('languages.edit', $language->id);
                    $deleteUrl = route('languages.destroy', $language->id);
                    $csrfToken = csrf_token();

                    return '<div class="text-center">
                        <a href="' . $editUrl . '" class="edit btn btn-primary btn-sm"><i class="bi bi-pencil-square"></i></a>
                        <a data-bs-toggle="modal" href="#delete_modal_' . $language->id . '" class="btn btn-danger btn-sm" title="Delete">
                            <i class="bi bi-trash"></i>
                        </a>
                        <div id="delete_modal_' . $language->id . '" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Confirmation</h4>
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">×</button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Are you sure you want to delete this item? This action cannot be undone and you will be unable to recover any data.</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-bs-dismiss="modal">Cancel</button>
                                        <form action="' . $deleteUrl . '" method="POST">
                                            <input type="hidden" name="_token" value="' . $csrfToken . '">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <button type="submit" class="btn btn-danger">Yes, delete it!</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>';
                })
                ->make(true);
        }

        return view('admin.languages.index');
    }

    public function create()
    {
        return view('admin.languages.create');
    }

    public function store(Request $request)
    {
        // Validate the input data
        $validatedData = $request->validate([
            'language_name' => 'required|string|max:255',
            'language_code' => 'required|string|max:10',
            'language_in_guj' => 'required|string|max:255', // Validate the new field
        ]);

        // Create a new Language entry
        Language::create($validatedData);

        // Redirect or respond as needed
        return redirect()->route('languages.index')->with('success', 'Language added successfully!');
    }

    public function edit($id)
    {
        $language = Language::findOrFail($id);
        return view('admin.languages.edit', compact('language'));
    }

    public function update(Request $request, $id)
    {
        // Validate the input data
        $validatedData = $request->validate([
            'language_name' => 'required|string|max:255',
            'language_code' => 'required|string|max:10',
            'language_in_guj' => 'required|string|max:255', // Validate the new field
        ]);

        // Find the language record
        $language = Language::findOrFail($id);

        // Update the record
        $language->update($validatedData);

        // Redirect or respond as needed
        return redirect()->route('languages.index')->with('success', 'Language updated successfully!');
    }

    public function destroy($id)
    {
        $language = Language::findOrFail($id);
        $language->delete();

        return redirect()->route('languages.index')->with('success', 'Language deleted successfully.');
    }
}
