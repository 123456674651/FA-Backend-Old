<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Aggriment;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;

class AgreementController extends Controller
{
    /**
     * Display a listing of agreements.
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $agreements = Aggriment::with(['party1', 'party2', 'category', 'subCategory'])->latest();
          

            return DataTables::of($agreements)
                ->addIndexColumn()
                ->addColumn('party_1_name', function ($row) {
                    return $row->party1 ? $row->party1->name : 'N/A';
                })
                ->addColumn('party_2_name', function ($row) {
                    return $row->party2 ? $row->party2->name : 'N/A';
                })
                ->addColumn('agreement_name', function ($row) {
                    $catName = $row->category ? $row->category->category_name : null;
                    $subCatName = $row->subCategory ? $row->subCategory->category_name : null;

                    if ($catName) {
                        return $catName . ' - ' . $subCatName;
                    } elseif ($catName) {
                        return $catName;
                    } else {
                        return 'N/A';
                    }
                })
                ->editColumn('created_at', function ($row) {
                    return $row->created_at ? $row->created_at->format('Y-m-d H:i') : 'N/A';
                })
                ->addColumn('action', function ($row) {
                    $viewUrl = route('agreements.show', $row->id);
                    return '<div class="text-center">
                        <a href="' . $viewUrl . '" class="btn btn-dark btn-sm"><i class="bi bi-eye"></i> View</a>
                    </div>';
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('admin.agreements.index');
    }

    /**
     * Display the specified agreement.
     */
    public function show(Aggriment $agreement)
    {
        $agreement->load(['party1', 'party2', 'category']);
        
        return view('admin.agreements.show', compact('agreement'));
    }
}
